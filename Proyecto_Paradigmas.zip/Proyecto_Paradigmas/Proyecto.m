clear, clc

signo_suma = [-1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,1,1,1,1,1,1,1,-1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1];               

signo_resta= [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,1,1,1,1,1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];


signo_multiplicacion = [1,-1,-1,-1,-1,-1,1,-1,1,-1,-1,-1,1,-1,-1,-1,1,-1,1,-1,-1,-1,-1,-1,1,-1,-1,-1,-1,-1,1,-1,1,-1,-1,-1,1,-1,-1,-1,1,-1,1,-1,-1,-1,-1,-1,1];

signo_division = [-1,-1,-1,-1,-1,-1,-1,-1,-1,1,1,1,-1,-1,-1,-1,1,1,1,-1,-1,1,1,1,1,1,1,1,-1,-1,1,1,1,-1,-1,-1,-1,1,1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1];

signo_igualdad = [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,1,1,1,1,1,1,-1,-1,-1,-1,-1,-1,-1,1,1,1,1,1,1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];

signo_desigualdad = [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,-1,1,1,1,1,1,1,1,-1,-1,-1,1,-1,-1,-1,1,1,1,1,1,1,1,-1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];

signo_porcentaje = [-1,-1,-1,-1,-1,-1,1,-1,1,-1,-1,-1,1,-1,1,-1,1,-1,1,-1,-1,-1,1,-1,1,-1,-1,-1,-1,-1,1,-1,1,-1,-1,-1,1,-1,1,-1,1,-1,1,-1,-1,-1,1,-1,-1];

signo_raiz = [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,1,1,-1,-1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,1,1,-1,-1,1,-1,-1,-1,-1,1,-1,1,-1,-1,-1,-1,-1,1,1,-1,-1];

signo_infinito = [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,1,-1,-1,1,1,-1,1,-1,1,1,-1,1,-1,1,1,-1,-1,1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];


signo_sigma = [,1,1,1,1,1,1,1,-1,1,-1,-1,-1,1,-1,-1,-1,1,-1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,-1,-1,1,-1,-1,-1,-1,-1,1,-1,-1,-1,1,-1,1,1,1,1,1,1,1];

                        
##col=7;
##fil1=7;
##
##for colum1=1:col;
##  for fil=1:fil1;
##    if (signo_sigma(colum1,fil)) ~=-1
##      fprintf('%d',signo_sigma(colum1,fil))
##    endif
##    if (signo_sigma(colum1,fil)) ==-1
##      fprintf(' ')
##    endif
##  endfor
##  fprintf("\n")
##endfor
                   
suma = signo_suma(:) * signo_suma(:)';

resta = signo_resta(:) * signo_resta(:)';

multiplicacion = signo_multiplicacion(:) * signo_multiplicacion(:)';

division = signo_division(:) * signo_division(:)';

igualdad = signo_igualdad(:) * signo_igualdad(:)';

desigualdad = signo_desigualdad(:) * signo_desigualdad(:)';

porcentaje = signo_porcentaje(:) * signo_porcentaje(:)';

raiz = signo_raiz(:) * signo_raiz(:)';

infinito = signo_infinito(:) * signo_infinito(:)';

sigma = signo_sigma(:) * signo_sigma(:)';

w1 = suma+resta+multiplicacion+division+igualdad+desigualdad+porcentaje+raiz+infinito+sigma;

w = w1 - diag(diag(w1));

x = [-1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,1,1,1,1,1,1,1,-1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1];          
u0 = x;
c=1;

ulast = x;
while(1)
  u0 = u0*w;
  
  for i=1:1:49
    if u0(i)>0
      u0(i) = 1;
     else
      u0(i) = -1;
     endif
  endfor
  
  if (ulast == u0)
        
        fprintf('Resultado encontrado: \n\n');
        u0
        ulast 
        
      fprintf ('\n Matrices recorridas hasta hallar el resultado: %d \n', c);
     break;  
  endif

  c = c + 1;
  ulast = u0;
end